import { startServer } from './server.js';

export default async config => {
  startServer();
};
