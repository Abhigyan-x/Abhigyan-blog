module.exports = require('../unit/.eslintrc.cjs');
